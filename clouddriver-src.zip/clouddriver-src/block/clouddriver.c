/*
 * CloudDriver - integrate cloud storage seamlessly into a computer 
 * 
 * (part of code learned from /drivers/block/nbd.c)
 */
 
#include <linux/major.h>
#include <linux/blkdev.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/moduleparam.h>
#include <linux/fs.h>
#include <linux/bio.h>
#include <linux/ioctl.h>

#include "clouddriver.h"

#define DRIVER_DESC   "A block device driver for driving cloud storage"

static struct cloud_device *cloud_dev;
static int max_part = 16;
static DEFINE_SPINLOCK(clouddrive_lock);

/*
 * request handler
 */ 
static void do_clouddrive_request(struct request_queue *q)
{
	
}

static int clouddrive_ioctl(struct block_device *bdev, fmode_t mode,
			unsigned int cmd, unsigned long arg)
{
	return 0;
}
static const struct block_device_operations clouddrive_fops = 
{
	.owner = THIS_MODULE,
	.ioctl = clouddrive_ioctl,
};

static int __init cloud_init(void)
{
	int err = -ENOMEM;
	unsigned int major = UNNAMED_MAJOR;
	
	if( (major = register_blkdev(0, "clouddrive")) < 0){
		err = -EIO;
		return err;
	}
	printk(KERN_INFO "clouddrive: registered device at major %u\n", major);
	
	cloud_dev = kcalloc(1, sizeof(*cloud_dev), GFP_KERNEL);
	if(!cloud_dev){
		return -ENOMEM;
	}
	
	struct gendisk *disk = alloc_disk(max_part);
	if(!disk){
		goto out;
	}
	
	disk->major = major;
	disk->first_minor = 0;
	disk->fops = &clouddrive_fops;
	sprintf(disk->disk_name, "clouddrive%d", 0);
	disk->queue = blk_init_queue(do_clouddrive_request, 
				&clouddrive_lock);
	if(!disk->queue){
		put_disk(disk);
		goto out;
	}
	add_disk(disk);
	cloud_dev->disk = disk;
	
  	return 0;
out:
	put_disk(disk);
	kfree(cloud_dev);
	return err;
}

static void __exit cloud_cleanup(void)
{
	struct gendisk *disk = cloud_dev->disk;
	unsigned major = disk->major;
	if(disk){
		del_gendisk(disk);
		blk_cleanup_queue(disk->queue);
		put_disk(disk);
	}
	unregister_blkdev(major, "clouddrive");
	kfree(cloud_dev);
  	printk(KERN_INFO "clouddrive: unregistered device at major %u\n", major);
	
}

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION(DRIVER_DESC);

module_init(cloud_init);
module_exit(cloud_cleanup);
