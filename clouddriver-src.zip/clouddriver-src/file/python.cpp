/* 
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *  
 *  Python wrap interface. 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#include "python.h"

/* 
 * wrap func for python/operate-xml.py
 *
 * On success, return 0
 */
int operate_xml(const char * fusePath, mode_t mode, unsigned int opr) {
	int ret = 0; 
	char s[CMD_LEN]; 
	int tmp; 
	int mode_num; 
	 
	/* simplify: 0 -> dir; else -> file */
	if (S_ISDIR(mode)) 
		mode_num = MODE_DIR; 
	else
		mode_num = MODE_FILE; 

	assert(opr==CREATE_ELEM || opr==DELETE_ELEM); 
	
	string str = (opr==CREATE_ELEM)?"create":"delete"; 

#ifdef PYTHON_FINISHED
	sprintf(s, "%s %s %s %u %s %s", operatexmlPath.c_str(), str.c_str(),
			fusePath, mode_num, xmlPath.c_str(), clouddriver_data->rootdir); 
	log_msg("operate_xml(\"%s\") starts with system(\"%s\")\n", str.c_str(), s); 
	tmp = system(s); 
	if (tmp == -1) 
		ret = clouddriver_error("from operate_xml() calling operate-xml.py\n"); 
#endif

	return ret; 
}

/*
 * wrap func for python/xml-to-dir.py 
 *
 * On success, return 0
 */
int xml_to_dir() {
	int ret = 0; 
	char s[CMD_LEN]; 
	int tmp; 

#ifdef PYTHON_FINISHED
	sprintf(s, "%s %s %s", xmltodirPath.c_str(), xmlPath.c_str(), 
			clouddriver_data->rootdir); 
	log_msg("xml_to_dir() starts with system(\"%s\")\n", s); 
	tmp = system(s); 
	if (tmp == -1) 
		ret = clouddriver_error("from xml_to_dir() calling xml-to-dir.py\n"); 
#endif

	return ret; 
}
