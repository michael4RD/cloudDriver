/* 
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#ifndef _CACHEMANAGEMENT_H_
#define _CACHEMANAGEMENT_H_
#include <stdio.h>

#include "clouddriver.h"
#include "log.h"
#include "sync.h"

extern void init_cache(); 
extern void recordAccess_cache(const char *, unsigned int); 
extern bool isCached(const char *); 
extern bool isCacheFull(); 
extern int replace_algo_cache(); 
extern int replace(const char *, mode_t); 
extern int evict(int *); 
extern void garbage_collection_cache(); 

#endif
