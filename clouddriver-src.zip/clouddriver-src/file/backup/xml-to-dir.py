#!/usr/bin/env python
#
#  Retrieve XML representation to the test directory
#
#  USAGE: ./xml-to-dir.py xmlfilePath testPath
#
#  NOTE: try to not use tab in python code. Use space instead. 
#  TOOL: python -m tabnanny xml-to-dir.py
#
#  DOC to generate/parse XML file: 
#  http://docs.python.org/library/xml.dom.html
#  http://docs.python.org/library/xml.dom.minidom.html 
#
#  TODO: file content concern
#

import os
import errno
import sys
import math
from xml.dom import minidom, Node

if(len(sys.argv) != 3):
    print "Usage: ./xml-to-dir.py xmlfilePath testPath"
    exit(1)

xmlfilePath = sys.argv[1]
testPath = sys.argv[2]

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc:
        if exc.errno == errno.EEXIST: 
            pass
        else: raise

def print_attr(parentElem, me):
    print "For %s: \n" % os.path.join(parentElem.getAttribute('path'),
                me.getAttribute('name'))
    attrs = me.attributes
    for attrName in attrs.keys():
        attrNode = attrs.get(attrName)
        attrValue = attrNode.nodeValue
        print "AttributeName: %s --> AttributeValue: %s\n" % \
                (attrName, attrValue)

def makedir(elem, callback):
    for node in elem.childNodes:
        if node.nodeType == Node.ELEMENT_NODE:
            # print "ELEMENT_NODE: %s\n" % node.nodeName
            nodename = node.nodeName
            if nodename == 'Dir':
                # print "Dir: %s\n" % node.getAttribute('path')
                mkdir_p(os.path.join(testPath,
                    node.getAttribute('path')))
                makedir(node, callback)
            elif nodename == 'File':
                # print "File: %s\n" % node.getAttribute('name')
                os.system("touch " + os.path.join(testPath,
                    elem.getAttribute('path'), node.getAttribute('name')))
                callback(elem, node)
            else:
                print "Unknown node name: %s\n" % nodename

def main(): 
    doc = minidom.parse(xmlfilePath)
    # rootnode = doc.documentElement
    makedir(doc, print_attr)

if __name__ == '__main__':
    mkdir_p(testPath)
    main()
