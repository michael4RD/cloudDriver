#!/usr/bin/env python
#
#  Create XML representation of the Cache directory
#
#  USAGE: ./cache-to-xml.py cache > xmlfile
#
#  NOTE: try to not use tab in python code. Use space instead. 
#  TOOL: python -m tabnanny cache-to-xml.py
#
#  DOC to generate/parse XML file: 
#  http://docs.python.org/library/xml.dom.html
#  http://docs.python.org/library/xml.dom.minidom.html 
#

import os
import sys
import math
from xml.dom.minidom import Document

if(len(sys.argv) != 2):
    print "Usage: ./cache-to-xml.py rootPath > xmlName"
    exit(1)

rootPath = sys.argv[1]

doc = Document()

def makenode(path, callback):
    "Return a document node contains a directory tree for the path."
    node = doc.createElement('Dir')
    node.setAttribute('path', path)
    for f in os.listdir(path):
        fullname = os.path.join(path, f)
        if os.path.isdir(fullname):
            elem = makenode(fullname, callback)
        else:
            elem = doc.createElement('File')
            # python pass parameters by reference
            callback(fullname, elem, f)
        node.appendChild(elem)
    return node

def collectMetadata(fullpath, elem, f):
    stat = os.stat(fullpath)
    # ID of device containing file
    elem.setAttribute('dev', unicode(stat.st_dev))
    # inode number
    elem.setAttribute('ino', unicode(stat.st_ino))
    # file mode for protection
    elem.setAttribute('mode', unicode(stat.st_mode))
    # number of hard links
    elem.setAttribute('nlink', unicode(stat.st_nlink))
    # user ID of owner
    elem.setAttribute('uid', unicode(stat.st_uid))
    # group ID of owner
    elem.setAttribute('gid', unicode(stat.st_gid))
    # device ID (if special file)
    elem.setAttribute('rdev', unicode(stat.st_rdev))
    # total size, in bytes
    elem.setAttribute('size', unicode(stat.st_size))
    # block size for file system IO
    elem.setAttribute('blksize', unicode(stat.st_blksize))
    # number of 512B blocks allocated
    elem.setAttribute('blocks', unicode(stat.st_blocks))
    # last access time
    elem.setAttribute('atime', unicode(stat.st_atime))
    # last modification time
    elem.setAttribute('mtime', unicode(stat.st_mtime))
    # last status change time
    elem.setAttribute('ctime', unicode(stat.st_ctime))
    
    # file name, in relevant path
    elem.setAttribute('name', f)
    

doc.appendChild(makenode(rootPath, collectMetadata))

print doc.toprettyxml(indent="  ")
