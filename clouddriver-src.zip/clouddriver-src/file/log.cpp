/* 
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *  
 * log every operation happens in the FUSE file system, partially
 * borrowed from BBFS.
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */

#include "log.h"

FILE *log_open()
{
    FILE *logfile;
    
    /* 
	 * very first thing, open up the logfile and mark that we got in
     * here.  If we can't open the logfile, we're dead.
	 */
    logfile = fopen("clouddriver.log", "w");
    if (logfile == NULL) {
		perror("logfile");
		exit(EXIT_FAILURE);
    }
    
    /* set logfile to line buffering */
    setvbuf(logfile, NULL, _IOLBF, 0);

    return logfile;
}

void log_close(FILE *f) 
{
	fclose(f); 	
	return; 
}

void log_msg(const char *format, ...)
{
    va_list ap;
    va_start(ap, format);

    vfprintf(CLOUDDRIVER_DATA->logfile, format, ap);
}
    
/* 
 * struct fuse_file_info keeps information about files (surprise!).
 * This dumps all the information in a struct fuse_file_info.  The struct
 * definition, and comments, come from /usr/include/fuse/fuse_common.h
 * Duplicated here for convenience.
 */
void log_fi (struct fuse_file_info *fi)
{
    /* Open flags.  Available in open() and release() */
	log_struct(fi, flags, 0x%08x, );
	
    /* Old file handle, don't use */
	log_struct(fi, fh_old, 0x%08lx,  );

    /* In case of a write operation indicates if this was caused by a
        writepage */
	log_struct(fi, writepage, %d, );

    /* 
	 * Can be filled in by open, to use direct I/O on this file.
     * Introduced in version 2.4 
	 */
	log_struct(fi, direct_io, %d, );

    /* Can be filled in by open, to indicate, that cached file data
     * need not be invalidated.  Introduced in version 2.4 
	 */
	log_struct(fi, keep_cache, %d, );

    /* File handle.  May be filled in by filesystem in open().
     * Available in all other file operations 
	 */
	log_struct(fi, fh, 0x%016llx,  );
	
    /* Lock owner id.  Available in locking operations and flush */
	log_struct(fi, lock_owner, 0x%016llx, );
};

/* 
 * This dumps the info from a struct stat.  The struct is defined in
 * <bits/stat.h>; this is indirectly included from <fcntl.h>
 */
void log_stat(struct stat *si)
{
	/* ID of device containing file */
	log_struct(si, st_dev, %lld, );
	
    /* inode number */
	log_struct(si, st_ino, %lld, );
	
    /* protection */
	log_struct(si, st_mode, 0%o, );
	
    /* number of hard links */
	log_struct(si, st_nlink, %d, );
	
    /* user ID of owner */
	log_struct(si, st_uid, %d, );
	
    /* group ID of owner */
	log_struct(si, st_gid, %d, );
	
    /* device ID (if special file) */
	log_struct(si, st_rdev, %lld,  );
	
    /* total size, in bytes */
	log_struct(si, st_size, %lld,  );
	
    /* blocksize for filesystem I/O */
	log_struct(si, st_blksize, %ld,  );
	
    /* number of blocks allocated */
	log_struct(si, st_blocks, %lld,  );

    /* time of last access */
	log_struct(si, st_atime, 0x%08lx, );

    /* time of last modification */
	log_struct(si, st_mtime, 0x%08lx, );

    /* time of last status change */
	log_struct(si, st_ctime, 0x%08lx, );
}

void log_statvfs(struct statvfs *sv)
{
    /* file system block size */
	log_struct(sv, f_bsize, %ld, );
	
    /* fragment size */
	log_struct(sv, f_frsize, %ld, );
	
    /* size of fs in f_frsize units */
	log_struct(sv, f_blocks, %lld, );
	
    /* # free blocks */
	log_struct(sv, f_bfree, %lld, );
	
    /* # free blocks for non-root */
	log_struct(sv, f_bavail, %lld, );
	
    /* # inodes */
	log_struct(sv, f_files, %lld, );
	
    /* # free inodes */
	log_struct(sv, f_ffree, %lld, );
	
    /* # free inodes for non-root */
	log_struct(sv, f_favail, %lld, );
	
    /* file system ID */
	log_struct(sv, f_fsid, %ld, );
	
    /* mount flags */
	log_struct(sv, f_flag, 0x%08lx, );
	
    /* maximum filename length */
	log_struct(sv, f_namemax, %ld, );
	
}

void log_utime(struct utimbuf *buf)
{
	log_struct(buf, actime, 0x%08lx, );
	
	log_struct(buf, modtime, 0x%08lx, );
}
