/* 
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *  
 * Implemented functions to add changed files to the changedfile list
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#include "changelist.h"

/* open the changelist file for write. Remove it if it has existed */ 
FILE * changelist_open()
{
    FILE *file;
    
	/* remove if previously exists */
	system("rm -rf changelist"); 

	/* open in append mode */
    file = fopen("changelist", "a+");
    if (file == NULL) {
		log_msg("ERR: changelist_open");
		exit(EXIT_FAILURE);
    }
    
#if 0
    /* set file to line buffering */
    setvbuf(file, NULL, _IOLBF, 0);
#endif

    return file;
}

/* close a file */
void changelist_close(FILE *f) 
{
	fclose(f); 	
	return; 
}

/* add entry to changelist */
void changelist_add(char fpath[PATH_MAX], FILE *f) 
{
	size_t res, size; 
	char enter[3] = "\n"; 
#if 0
	log_msg("In changelist_add==>\n"); 
#endif

	size = strlen(fpath); 
	res = fwrite(fpath, sizeof(char), size, f); 
	if (res != size) {
		log_msg("ERR: changelist_add: fwrite failed %s\n", strerror(errno)); 
		exit(EXIT_FAILURE); 
	}

	res = fwrite(enter, sizeof(char), strlen(enter), f); 
	if (res != strlen(enter)) {
		log_msg("ERR: changelist_add: fwrite enter key failed %s\n", strerror(errno)); 
		exit(EXIT_FAILURE); 
	}

	fflush(f); 
#if 0
	log_msg("Out of changelist_add<==\n"); 
#endif
}
