/*
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#ifndef CLOUDDRIVER_H_
#define CLOUDDRIVER_H_

/*
 * The FUSE API has been changed a number of times.  So, our code
 * needs to define the version of the API that we assume.  As of this
 * writing, the most current API version is 26
 */
#define FUSE_USE_VERSION 26 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/*
#ifdef linux
//For pread()/pwrite() 
#define _XOPEN_SOURCE 500
#endif
*/

#include <fuse.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>
#include <fcntl.h>
#include <dirent.h>
#include <ctype.h>
#include <libgen.h>
#include <limits.h>
#include <errno.h>
#include <sys/statfs.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/xattr.h>
#include <string>

using std::string; 

#include "log.h"
#include "changelist.h"
#include "cacheManagement.h"
#include "sync.h"
#include "python.h"

/* maintain clouddriver state in here */
#include <limits.h>
#include <stdio.h>
struct clouddriver_state {
    FILE *logfile;				/* file pointer to log file */
    char *rootdir;				/* FUSE mount point */
	FILE *changelist;			/* file pointer to changelist */ 
    char *cwd;					/* current working path */
};

#define CLOUDDRIVER_DATA \
	((struct clouddriver_state *) fuse_get_context()->private_data)

/* 
 * Actions ordered by the caching algorithms for execution by the cache 
 * implementation 
 */
#define COPY_CLOUD_RAM  0x13 	/* copy from CLOUD to RAM and read file from RAM */
#define COPY_SSD_RAM  0x12 		/* copy from SSD to RAM and read file from RAM */
#define COPY_CLOUD_SSD  0x11	/* copy from CLOUD to SSD and read file from SSD */

#define READ_FROM_RAM 0x02		/* read file from RAM */
#define READ_FROM_SSD 0x01		/* read file from SSD */
#define READ_FROM_CLOUD 0x00	/* read file from CLOUD */

#define STATE_ACCESS 0x00000001 /* access bit */
#define STATE_INVALID 0x00000010	/* invalid bit */
#define STATE_SKIP	 0x00000100 /* skip bit when scan */

#define SET_VALID 	1			/* mark certain record valid */
#define SET_INVALID 0			/* mark certain record invalid */

#define PUT	0					/* put a file/dir to AWS */
#define GET	1					/* get a file/dir from AWS */
#define DEL	2					/* delete a file/dir in AWS */

#define CREATE_ELEM	0			/* create one element in XML */
#define DELETE_ELEM 1			/* delete one element in XML */

#define MODE_DIR 	0			/* dir mode */
#define MODE_FILE	1			/* file mode */

#define CACHE_SIZE 	10*1024*1024	/* 10GB in unit of KB */
#define CMD_LEN		1024			/* define command line length */
#define BUCKET_LEN	20				/* define bucket name length */

#define PYTHON_FINISHED				/* temporary define */	

/* In memory data structure for access control */
typedef struct file_cache_record {
	char* fusePath;				/* relative path of the file provided by FUSE */
	char* fullPath;				/* full path */ 
	char* cloudKey;				/* key representation of the file */

	off_t fileSize;				/* file size */
	time_t lastAccess;			/* timestamp of the last access */
#if 0
	int isRAM;					/* RAM cache is not considered at this moment */
#endif
	uint32_t isSSD;				/* whether the file exists in the SSD */
	uint32_t dirty; 			/* whether the file record is dirty or not */	
	uint32_t state; 		    /* state of the file; used for WSClock cache replacement */
} CacheRecord; 

/* cache header for cache management */
typedef struct cache_header {
	unsigned long free_space; 		/* in unit of KB */
	unsigned long total_space; 		/* in unit of KB */
	int 	 eviction_cursor;  	/* cursor used by WSClock algo */
} CacheHeader; 

extern clouddriver_state *clouddriver_data; 

extern CacheRecord *rec; 
extern uint64_t rec_cur; 
extern uint64_t rec_array_size; 
extern uint64_t rec_step; 
extern CacheHeader *cacheHeader; 
extern string bucketName; 
extern string pythonPath; 
extern string xmlPath; 
extern string operatexmlPath; 
extern string getputfilePath; 
extern string syncfilePath; 
extern string xmltodirPath; 
extern string changelistPath; 

extern int clouddriver_error(string str); 
#endif /* CLOUDDRIVER_H_ */
