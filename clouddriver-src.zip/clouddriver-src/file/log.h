#ifndef _LOG_H_
#define _LOG_H_
#include <stdio.h>

#include "clouddriver.h"

/* macro to log fields in structs */
#define log_struct(st, field, format, typecast) \
  log_msg("    " #field " = " #format "\n", typecast st->field)

extern FILE *log_open(void);
extern void log_close(FILE *f); 
extern void log_fi (struct fuse_file_info *fi);
extern void log_stat(struct stat *si);
extern void log_statvfs(struct statvfs *sv);
extern void log_utime(struct utimbuf *buf);
extern void log_msg(const char *format, ...);
#endif
