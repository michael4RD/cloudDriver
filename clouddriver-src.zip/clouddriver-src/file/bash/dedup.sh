#!/bin/bash

# 
# Remove duplicate file paths in changelist
# 
# USAGE: ./dedup.sh changelist
#

# NOTE: bash counts filename as the first command argument
if [ $# -ne 1 ]; then
	echo "USAGE: ./dedup.sh filename"	
	exit
fi

# uniq has options to print only dup lines or exclude dup lines
sort $1 | uniq > $1_dedup
