#!/usr/bin/gawk -f
# 
# convert unix timestamp into human readable format(MM/DD/YY). This is because 
# we want to use 'touch' to update time attributes for files and 'touch' only 
# accepts human readable format.  
# 
# To use it, we need to install gawk: sudo apt-get install gawk   
#
{ print strftime("%c", $0); }
