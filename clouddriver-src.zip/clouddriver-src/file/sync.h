/* 
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#ifndef _SYNC_H_
#define _SYNC_H_
#include <stdio.h>

#include "clouddriver.h"
#include "log.h"

extern int sync_file(const char * path, unsigned int opr); 
extern int sync_all(const char * rootdir); 
extern int sync_xml(unsigned int opr); 

#endif
