/* 
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *  
 * Cache Implementation.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#include "cacheManagement.h"

/* Initialize data for cache management */
void init_cache (void) {
	rec_cur = 0; 
	rec_array_size = 100; 
	rec_step = 100; 
	/* free in clouddriver_destroy */
	rec = (CacheRecord *)malloc(rec_array_size * sizeof(CacheRecord)); 
	assert(rec != NULL); 
	
	/* free in clouddriver_destroy */
	cacheHeader = (CacheHeader *)malloc(sizeof(CacheHeader)); 
	assert(cacheHeader != NULL); 	

	cacheHeader->total_space = CACHE_SIZE; 
	cacheHeader->free_space = CACHE_SIZE; 
	cacheHeader->eviction_cursor = -1; 
}

/* generate full fusePath */
static char * getFullPath(const char * fusePath) {
	char * fullPath = NULL; 
	unsigned int len = strlen(clouddriver_data->rootdir)+1 + 
		strlen(fusePath)+1; 

	assert(fusePath != NULL); 

	/* remember to free space when the fusePath is deleted */
	fullPath = (char *)malloc(len*sizeof(char)); 
	assert(fullPath != NULL); 

	strcpy(fullPath, clouddriver_data->rootdir); 
	strcat(fullPath, fusePath); 

	return fullPath; 
}

/* create cloud key */
static char * createCloudKey(const char * fullPath) {
	char * cloudKey = NULL; 
	unsigned int len = strlen(fullPath) + 1; 

	assert(fullPath != NULL); 

	/* remember to free space when the fuse fuse path is deleted */
	cloudKey = (char *) malloc(len * sizeof(char)); 
	assert(cloudKey != NULL); 

	strcpy(cloudKey, fullPath); 
	
	/* replace '/' with '#' */
	for (unsigned int i=0; i<len; i++) {
		if (cloudKey[i]=='/') 
			cloudKey[i] = '#'; 
		else 
			continue; 
	}

	return cloudKey; 	
}

/* Called when cache record is accessed */
void recordAccess_cache(const char * fusePath, unsigned int opr) {
	uint64_t i;
	struct stat buf;

	/* search if cache record exists */
	for (i=0; i<rec_cur; i++)
	{
		if (strcmp(rec[i].fusePath, fusePath) == 0)
		{
			/* update if exists */
			rec[i].lastAccess = time(NULL);
			rec[i].state |= (opr==SET_INVALID)? STATE_INVALID: STATE_ACCESS;
			rec[i].dirty = 1; 
			if (opr == SET_INVALID) {
				/* free memory to avoid memory leak */
				free(rec[i].fusePath); 
				free(rec[i].fullPath); 
				free(rec[i].cloudKey); 
			}
			return;
		}
	}

	/* if not exists */
	if (opr == SET_INVALID)	/* it is triggered by file unlink */
		return; 
	
	/* remember to free space when deleted */
	rec[rec_cur].fusePath = strdup(fusePath);
	assert(rec[rec_cur].fusePath != NULL);

	rec[rec_cur].fullPath = getFullPath(fusePath);	
	rec[rec_cur].cloudKey = createCloudKey(rec[rec_cur].fullPath); 				

	rec[rec_cur].state = 0; 
	rec[rec_cur].state |= STATE_ACCESS;
	rec[rec_cur].lastAccess = time(NULL);
	rec[rec_cur].dirty = 0; 
	rec[rec_cur].isSSD = 1; 			

	stat(rec[rec_cur].fullPath, &buf);
	rec[rec_cur].fileSize = buf.st_size;

	rec_cur++;

	/* file record does not exist, create one */
	if (rec_cur > rec_array_size)
	{
		/* extend array */
		rec_array_size += rec_step;
		rec = (CacheRecord *)realloc(rec, rec_array_size * sizeof(CacheRecord));
		assert(rec != NULL); 
	}
	return; 
}

/* update record in @pos */
static void updateRecord_pos_cache(const char * fusePath, int pos, unsigned int opr) {
	struct stat buf;

	assert(opr == SET_VALID); 
	
	/* remember to free space when deleted */
	rec[pos].fusePath = strdup(fusePath);
	assert(rec[pos].fusePath != NULL);

	rec[pos].fullPath = getFullPath(fusePath);	
	rec[pos].cloudKey = createCloudKey(rec[pos].fullPath); 				

	rec[pos].state = 0; 
	rec[pos].state |= STATE_ACCESS;
	rec[pos].lastAccess = time(NULL);
	rec[pos].dirty = 0; 
	rec[pos].isSSD = 1; 			

	stat(rec[pos].fullPath, &buf);
	rec[pos].fileSize = buf.st_size;

	return; 
}

/* Whether a file is already cached or not */
bool isCached(const char * fusePath) {
	uint64_t i;
	bool ret = false;
	
	for (i = 0; i < rec_cur; i++) {
		if (rec[i].state & STATE_INVALID) 
			continue; 
		if (strcmp(rec[i].fusePath, fusePath) == 0) {
			ret = true;
			break;
		}
	}

	return ret;
}

/* Make decision on whether the cache is full or not */
bool isCacheFull() {
	if (cacheHeader->free_space <= 0) 
		return true; 
	else 
		return false; 
}

/* Return the to-bo-placed record index by WSClock algorithm */
int replace_algo_cache() {
	int i = cacheHeader->eviction_cursor; 

	do {
		/* if end is reached, circle to beginning */
		if (++i >= (int)rec_cur) {
			i = 0; 	
			log_msg("replace_cache() cursor in %d\n", i); 
		}

		if (rec[i].state & STATE_ACCESS) { 	/* if bit is set */
			rec[i].state ^= STATE_ACCESS;   /* clear the bit */
			log_msg("replace_cache() cursor in %d is reset\n", i); 
		} else {
			rec[i].state |= STATE_ACCESS; 
			cacheHeader->eviction_cursor = i; 
			log_msg("replace_cache() cursor %d returned\n", i); 
			return i; 
		}
	} while(1); 
	
	log_msg("BUG: This error message should never be printed\n"); 
}

/* cache eviction 
 *
 * On success, return 0
 */
int evict(int * ind) {
	int ret = 0; 
	char s[CMD_LEN]; 
	int tmp; 
#if 0
	mode_t mode = 0; 		/* it makes no sense to delete operation */
#endif 

	int index = replace_algo_cache(); 	
	assert(index>=0 && index <= (int)rec_cur); 

	/* set func value */
	*ind = index; 

	if (rec[index].dirty == 1) {
		/* flush the file/dir to the cloud */
		tmp = sync_file(rec[index].fullPath, PUT); 
		if (tmp != 0) {
			ret = clouddriver_error("evict() calling sync_file()\n"); 
			goto error_exit; 
		}
	}

	/* before replacment, delete the file in cache */
	sprintf(s, "rm -rf %s", rec[index].fullPath); 
	tmp = system(s); 
	if (tmp == -1) {
		ret = clouddriver_error("evict() calling rm -rf \n"); 
		/* FIXME: roll back issue */
		goto error_exit; 
	}
	else  /* increase free space */
		cacheHeader->free_space += rec[index].fileSize; 

	/* update the record in rec[index] */
	recordAccess_cache(rec[index].fusePath, SET_INVALID); 

#if 0
	/* FIXME: before replacement, update XML file smartly */		
	tmp = operate_xml(rec[index].fusePath, mode, DELETE_ELEM); 
	if(tmp != 0) {
		ret =  clouddriver_error("evict() calling operate_xml() delete \n"); 
	}
#endif

error_exit: 
	return ret; 
}

/* 
 * real replacement function
 *
 * On success, return 0; 
 */
int replace(const char * fusePath, mode_t mode) {
	int ret = 0; 
	int tmp; 
	int index = 0; 			/* initialized to be 0 */

	/* first evict */
	tmp = evict(&index); 
	if (tmp != 0) {
		ret = clouddriver_error("replace() calling evict()\n"); 
		/* FIXME: roll back issue */
		goto error_exit; 
	}

	/* update the record in rec[index] */
	updateRecord_pos_cache(fusePath, index, SET_VALID);		/* NOTE: file/dir not created here */

#if 0
	/* FIXME: before replacement, update XML file smartly */		
	tmp = operate_xml(fusePath, mode, CREATE_ELEM); 
	if(tmp == -1) {
		ret = clouddriver_error("replace() calling operate_xml() create \n"); 
		goto error_exit; 
	}
#endif

error_exit: 
	return ret; 
}

/* Garbage collect cache records */
void garbage_collection_cache() {
	uint64_t i,j; 
	uint64_t cur = rec_cur; 
	
	for (i=0; i<rec_cur; i++) {
		/* if the file is deleted or skpped */
		if ((rec[i].state & STATE_INVALID) || (rec[i].state & STATE_SKIP)) {
			/* decrease the current number of records when file deleted */
			if (rec[i].state & STATE_INVALID) 
				cur--; 	
			for (j=i+1; j<rec_cur; j++) {
				if (rec[j].state & STATE_ACCESS) {
					/* copy record and set skip bit */
					rec[i] = rec[j]; 
					rec[j].state |= STATE_SKIP; 
					break; 
				}
			}
			/* if scans to the end */
			if (j>=rec_cur)
				break; 
		}/* end of if */
	}/* end of for */

	rec_cur = cur; 
	return; 
}
