#!/usr/bin/env python
#
#  Create an XML representation of the Cache directory
#
#  USAGE: ./cache-to-xml.py cache > xmlfile
#
#  NOTE: try to not use tab in python code. Use space instead. 
#  TOOL: python -m tabnanny cache-to-xml.py
#
#  DOC to generate/parse XML file: 
#  http://docs.python.org/library/xml.dom.html
#  http://docs.python.org/library/xml.dom.minidom.html 
#

import os
import sys
import math
import utils
from xml.dom.minidom import Document

logfile = sys.argv[0] + '.log'
try:
    logf = open(logfile, 'a')
except IOError:
    print "failed to open log file\nExit"
    exit(1)

if(len(sys.argv) != 2):
    logf.write("Usage: ./cache-to-xml.py rootPath > xmlName")
    logf.close()
    exit(1)

rootPath = sys.argv[1]

doc = Document()

def makeNode(path, callback):
    "Return a document node contains a directory tree for the path."
    node = doc.createElement('Dir')
    fusepath = utils.getFusePath(path, rootPath, logf)
    # if this dir is not in the FUSE root dir, add '/'
    if path != rootPath:
        fusepath = fusepath + '/'
    node.setAttribute('path', fusepath)
    # It is OK to keep the attributes of directory for now
    callback(path, node, os.path.basename(path));
    for f in os.listdir(path):
        fullname = os.path.join(path, f)
        if os.path.isdir(fullname):
            elem = makeNode(fullname, callback)
        else:
            elem = doc.createElement('File')
            # python pass parameters by reference
            callback(fullname, elem, f)
        node.appendChild(elem)
    return node

doc.appendChild(makeNode(rootPath, utils.collectMetadata))

print doc.toprettyxml(indent="  ")
logf.close()
