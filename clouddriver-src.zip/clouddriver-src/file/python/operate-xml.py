#!/usr/bin/env python
#
#  Dynamically operate or query the XML file
#
#  USAGE: ./operate-xml.py [create|delete|query] path mode xmlfile rootdir
#  
#  @path is FUSE path which starts from "/" by FUSE.
#  e.g:  
#         ./operate-xml.py query /test 1 xmlfile rootdir
#  @mode says file type. For simplicity, 0 --> dir, else --> file
#  @rootdir is needed to get attributes to creat a file/dir node. It can be
#  either the mountpoint or the cache dir in the current working dir.
#
#  NOTE: try to not use tab in python code. Use space instead. 
#  TOOL: python -m tabnanny cache-to-xml.py
#
#  DOC to generate/parse XML file: 
#  http://docs.python.org/library/xml.dom.html
#  http://docs.python.org/library/xml.dom.minidom.html 
#

import os
import sys
import math
from xml.dom.minidom import parse
from xml.dom import Node
import re
import utils

logfile = sys.argv[0] + ".log"
try:
    logf = open(logfile, 'a')
except IOError:
    print "failed to open log file"
    exit(1)

if(len(sys.argv) != 6):
    logf.write("Usage: ./operate-xml.py [create|delete|query]" + \
            "fusepath mode xmlfile rootdir\n")
    logf.close()
    exit(1)

oper = sys.argv[1]
path = sys.argv[2]
mode = sys.argv[3]
xmlfile = sys.argv[4]
rootdir = sys.argv[5]

def create(doc, path, rootdir, mode): 
    # create one element in xml file
    # 1. check the existence of a duplicate element. If existing, remove it 
    # first
    node = query(doc, path, mode)
    if node != -1:
        # delete this node
        parentNode = node.parentNode
        node = parentNode.removeChild(node)
        node.unlink()
    # 2. make new nodes
    # Given a path of a newly created file, we have to ensure all the dirs
    # up to that file exists. Create them if it does not.

    # 2.a remove the leading '/' from a path
    (nextdir, path) = utils.extractNextDirFromPath(path)
    (node, leftpath, existingpath) = \
        utils.getLongestMatchingDirNode(doc.documentElement, path, 0, logf)
    prefixpath = rootdir
    if existingpath != 0:
        prefixpath = prefixpath + '/' + existingpath
    utils.createNode(doc, node, leftpath, prefixpath, mode)
    return 0
 
def delete(doc, path, mode): 
    node = query(doc, path, mode)
    if node == -1:
        logf.write("could not find this node for delete\n")
        return -1
    else:
    # do the actual delete
        parentNode = node.parentNode
        node = parentNode.removeChild(node)
        node.unlink()
    return 0

# query a path in the XML file. 
# mode == 0: the path is a dir; otherwise, the path points to a file
#
def query(doc, path, mode):
    # return the element for the given path
    rootnode = doc.documentElement
    (nextdir, leftpath) = utils.extractNextDirFromPath(path)
    node = utils.findSubnode(rootnode, leftpath, mode, logf)
    if node != -1:
        return node
    else:
        return -1

def main(): 
    ret = 0
    doc = parse(xmlfile)
    if oper=="create":
        logf.write("create one element: " + path + "\n")
        create(doc, path, rootdir, mode)
        prettyxml = utils.getprettyXML(doc)
        f = open(xmlfile, 'w')
        # TODO: need to verify
        # it seems to me that write() will always succeed
        f.write(prettyxml)
        f.close()
    elif oper=="delete":
        logf.write("Delete one element: " + path + "\n")
        ret = delete(doc, path, mode)
        if ret == 0:
            prettyxml = utils.getprettyXML(doc)
            f = open(xmlfile, 'w')
            f.write(prettyxml)
            f.close()
        else:
            # delete() will fail only when it could not find that node in the
            # xmlfile. No bad effect takes here.
            logf.write("failed to delete the node\n")
            ret = -1
    elif oper=="query":
        logf.write("Query one element: " + path + "\n")
        node = query(doc, path, mode)
        if node == -1:
            logf.write("couldn't find it\n")
        else:
            logf.write("find it\n")
    else: 
        logf.write("Unknown operate: " + oper + "\n")
    doc.unlink()
    logf.close()
    return ret

if __name__ == '__main__':
    main()
