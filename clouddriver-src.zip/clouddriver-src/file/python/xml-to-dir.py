#!/usr/bin/env python
#
#  Restore the directory structure represented by the XML representation to 
#  the test directory. testPath does not need to be created in advance.
#
#  USAGE: ./xml-to-dir.py xmlfilePath testPath
#
#  NOTE: try to not use tab in python code. Use space instead. 
#  TOOL: python -m tabnanny xml-to-dir.py
#
#  DOC to generate/parse XML file: 
#  http://docs.python.org/library/xml.dom.html
#  http://docs.python.org/library/xml.dom.minidom.html 
#
#  TODO: file attributes concern
#

import os, stat, commands
import errno
import sys
import math
from xml.dom import minidom, Node

logfile = sys.argv[0] + ".log"
try:
    logf = open(logfile, 'a')
except IOError:
    print "failed to open log file"
    exit(1)

if(len(sys.argv) != 3):
    logf.write("Usage: ./xml-to-dir.py xmlfilePath testPath\n")
    logf.close()
    exit(1)

xmlfilePath = sys.argv[1]
testPath = sys.argv[2]

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc:
        if exc.errno == errno.EEXIST: 
            pass
        else: raise

def print_attr(parentElem, me):
    logf.write("For " + os.path.join(parentElem.getAttribute('path'),
                me.getAttribute('name')) + ":\n")
    attrs = me.attributes
    for attrName in attrs.keys():
        attrNode = attrs.get(attrName)
        attrValue = attrNode.nodeValue
        logf.write("AttributeName: " + attrName +" --> AttributeValue: "\
                + attrValue + "\n")

def set_attr(parentElem, me):
    if me.nodeName == 'File':
        fullpath = testPath + parentElem.getAttribute('path') + \
            me.getAttribute('name')
    elif me.nodeName == 'Dir':
        fullpath = testPath + me.getAttribute('path')
    else:
        logf.write("nodeName: " + me.nodeName + " not supported\n")
        logf.close()
        exit(1)
    logf.write("For " + fullpath + ":\n")
    attrs = me.attributes
    logf.write("\tAttribute: value\n")
    for attrName in attrs.keys():
        attrNode = attrs.get(attrName)
        attrValue = attrNode.nodeValue
        logf.write("\t " + attrName + ": " + attrValue + "\n")
        if attrName == 'mode':
            mode = int(attrValue);
            os.chmod(fullpath, mode)
        elif attrName == 'atime':
            (status, date) = commands.getstatusoutput("echo " + attrValue + \
             "| ../bash/convertunixtime.sh")
            os.system("touch -a -d '" + date + "' " + fullpath)
        elif attrName == 'mtime':
            (status, date) = commands.getstatusoutput("echo " + attrValue + \
             "| ../bash/convertunixtime.sh")
            os.system("touch -m -d '" + date + "' " + fullpath)
        # Cache is small. So far, do not try to take up cache.  
        # Instead, let cache management code takes care of this. 
        # FIXME: only modify the file size attribute to be attrValue
        #        Do not assign space to the file.
        #elif attrName == 'size':
        #   size = int(attrValue)
        #   f = open(fullpath, 'w');
        #   f.truncate(size);
        #   f.close();
    logf.write("\n")
    
def makedir(elem, callback):
    for node in elem.childNodes:
        if node.nodeType == Node.ELEMENT_NODE:
            # print "ELEMENT_NODE: %s\n" % node.nodeName
            nodename = node.nodeName
            if nodename == 'Dir':
                s = "Create Dir: " + node.getAttribute('path') + "\n"
                logf.write(s)
                mkdir_p(testPath + node.getAttribute('path'))
                callback(elem, node)
                makedir(node, callback)
            elif nodename == 'File':
                s = "Create File: " + node.getAttribute('name') + "\n"
                logf.write(s)
                fusepath = testPath + elem.getAttribute('path') + \
                               node.getAttribute('name')
                os.system("touch " + fusepath)
                callback(elem, node)
            else:
                logf.write("Unknown node name: " + nodename + "\n")

def main(): 
    doc = minidom.parse(xmlfilePath)
    # rootnode = doc.documentElement
    makedir(doc, set_attr)

if __name__ == '__main__':
    mkdir_p(testPath)
    logf.write("xml-to-dir.py starts\n"); 
    main()
    logf.write("xml-to-dir.py ends\n"); 
    logf.close()
