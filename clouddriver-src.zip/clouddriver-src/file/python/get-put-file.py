#!/usr/bin/env python
#
#  get/put a file from/to a bucket in S3, given a fullpath 
#
#  USAGE: ./get-put-file.py [g|p|d] fullpath bucket cachedir
#
#  @fullpath points to cache dir.
#
#  @cachedir is optional under certain condidtion: it is not needed 
#  to store xmlfile but is needed for user files. 
#  It is used to get the FUSE path from fullpath. Please note
#  that cachedir should not end with '/'.
#  e.g: 
#  ./get-put-file.py [g|p|d] /src/file/python/xmlfile bucket
#  ./get-put-file.py [g|p|d] /src/file/cache/test bucket /src/file/cache
#
#  get: get a file from the specified bucket in S3 and store it at filepath
#  put: put a file at filepath to the specified bucket in S3
#  delete: delete a file with the specified path in S3
#
#  FIXME: gpg requires passphrase everytime we access AWS. Disable it
#  for now. 1) Testing purpose; 2) FUSE incompatibility
# 
import os
import sys
# import from utils.py module
import utils

from boto.s3.connection import S3Connection
from boto.s3.key import Key
import boto

logfile = sys.argv[0] + '.log'
try:
    logf = open(logfile, 'a')
except IOError:
    print "failed to open log file\nExit"
    exit(1)

if len(sys.argv) != 4 and len(sys.argv) != 5:
    logf.write("Usage: ./get-put-file.py [g|p|d] fullpath bucketname " + \
        "[cachedir]\n")
    logf.close()
    exit(1)

oper = sys.argv[1]
filepath = sys.argv[2]
bucketname = sys.argv[3]
cachedir = 0
tmp = "/tmp/"

if len(sys.argv) == 5:
    cachedir = sys.argv[4]

user = "Michael"

if oper == 'g':
    logf.write("start to get file: " + filepath + "\n")
    # get key from the filepath
    key = utils.getKeyFromPath(filepath, cachedir, logf)
    if key == -1:
        logf.write("getKeyFromPath() failed\n")
        logf.close()
        exit(1)
    # connect to S3
    conn = S3Connection(utils.aws_access_key, utils.aws_secret_key)
    # get the bucket object
    logf.write("step --> conn.get_bucket()\n"); 
    bucket = conn.get_bucket(bucketname)
    # get the value for the this key
    logf.write("step --> Key()\n"); 
    keyobject = Key(bucket)
    keyobject.key = key
    filecontent = ''
    try: 
        logf.write("step --> keyobject.get_contents_from_string() "+ \
                filepath + "\n"); 
        filecontent = keyobject.get_contents_as_string()
    except boto.exception.S3ResponseError:
        # For the moment, if the key doesn't exist, we create an empty file. 
        logf.write("ERROR GET " + filepath + " from S3\n")
        logf.write("Create an empty file instead\n")
        if os.system("touch " + filepath) == -1:
             logf.write("failed to create an empty file\n")
             logf.close()
             exit(1)
        logf.close()
        exit(1)
    # restore the file content
    # re-create the encrypt and compressed tarball so that we can decrypt 
    # and decompress. 
    # [Note]: We might want to hide this file at a temporary directory,
    # not the directory that users are able to read
#    f = open(filepath + ".tar.gz.gpg", 'w')
    f = open(filepath + ".tar.gz", 'w')
    f.write(filecontent)
    f.close()

    # re-store the requested file
    # decrypt it
#    ret = os.system("gpg --output " + filepath + ".tar.gz" + " --decrypt " \
#              + filepath + ".tar.gz.gpg")
    # remove this file
#    os.system("rm " + filepath + ".tar.gz.gpg")
#    if ret == -1:
#        logf.write("failed to do decryption for requested file\n")
#        exit(ret)

    # decompress it
    ret = os.system("gunzip " + filepath + ".tar.gz")
    if ret == -1:
        logf.write("failed to do decompression for requested file\n")
        logf.close()
        # remove file.tar.gz
        os.system("rm " + filepath + ".tar.gz")
        exit(ret)

    # extract from the tarball. We need to first change to root dir 
    # because we create a tarball with a full path. And then remove this 
    # tarball make sure to get file to the right path in cache
    # this is automatically handled by tar. 
    ret = os.system("tar -C / -xf " + filepath + ".tar")
    if ret == -1:
        logf.write("failed to extract the tarball for requested file\n")
        logf.close()
        exit(ret)
    logf.write("get file: " + filepath + " success\n")

    os.system("rm " + filepath + ".tar")
elif oper == 'p':
    logf.write("start to put file: " + filepath +" to S3\n")
    if(os.path.exists(filepath) is False):
        s = filepath + "does not exist in cache\n"
        logf.write(s)
        logf.close()
        exit(1)
    # get key from the filepath
    key = utils.getKeyFromPath(filepath, cachedir, logf)
    if key == -1:
        logf.write("getKeyFromPath() failed\n")
        logf.close()
        exit(1)
    logf.write("step --> got the key: " + key + "\n"); 

    # step1: create an tarball with compression and encryption
    # 1.a create the tarball
    logf.write("step --> tar -cf " + tmp + key + ".tar " + filepath + "\n"); 
    ret = os.system("tar" + " -cf " + tmp + key + ".tar " + filepath)
    if ret == -1:
        logf.write("failed to create tarball for requested file\n")
        logf.close()
        exit(ret)

    # 1.b compress the tarball
    logf.write("step --> gzip -c " + tmp + key + ".tar > " + tmp \
            + key + ".tar.gz\n"); 
    ret = os.system("gzip -c " + tmp + key + ".tar > " + tmp + key + ".tar.gz")
    if ret == -1:
        logf.write("failed to do compression \n")
        logf.close()
        os.system("rm " + tmp + key + ".tar")
        exit(ret)
    # 1.c encrypt the tarball
    # before perform the following command, please do gpg --gen-key and
    # create key pairs for Michael/Xing
# NOTE: Disable for now
#    ret = os.system("gpg -e -r " + user + " " + key + ".tar.gz")
#    if ret == -1:
#        logf.write("failed to do encryption\n")
#        os.system("rm " + key + ".tar")
#        os.system("rm " + key + ".tar.gz")
#        exit(ret)
    # step2: store the tarball at the specified bucket in S3
    # connect to S3
    conn = S3Connection(utils.aws_access_key, utils.aws_secret_key)
    # get the bucket object
    logf.write("step --> conn.get_bucket()\n"); 
    bucket = conn.get_bucket(bucketname)
    # get the value for the this key
    logf.write("step --> Key()\n"); 
    keyobject = Key(bucket)
    keyobject.key = key
#    f = open(key + ".tar.gz.gpg", 'r')
    try:
        f = open(tmp + key + ".tar.gz", 'r')
    except IOError:
        logf.write("open " + tmp + key + ".tar.gz failed\n")
        logf.close()
        exit(1)

    logf.write("step --> k.set_contents_from_string() " + filepath + "\n"); 
    try:
        keyobject.set_contents_from_string(f.read())
    except boto.exception.S3ResponseError:
        logf.write("ERROR PUT" + filepath + " to S3\n")
        f.close()
        logf.close()
        exit(1)
    f.close()
    logf.write("put file: " + filepath + " success\n")

    # remove temporary files
    os.system("rm " + tmp + key + ".tar")
    os.system("rm " + tmp + key + ".tar.gz")
#    os.system("rm " + key + ".tar.gz.gpg")
elif oper == 'd':
    logf.write("start to delete file: " + filepath + "in S3\n")
    key = utils.getKeyFromPath(filepath, cachedir)
    if key == -1:
        logf.write("getKeyFromPath() failed\n")
        logf.close()
        exit(1)
    try:
        # connect to S3
        conn = S3Connection(utils.aws_access_key, utils.aws_secret_key)
        # get the bucket object
        bucket = conn.get_bucket(bucketname)
        bucket.delete_key(key)
    except boto.exception.S3ResponseError:
        logf.write("failed to delete key in S3: S3 reponse error\n")
        logf.close()
        exit(1)
    logf.write("delete file: " + filepath + " success\n")
else:
    logf.write("Unknown operate: " + oper + "\n")
logf.close()
