#include <unistd.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

int main ( int argc, char **argv )
{
	int ret = 0; 
	ret = system("/home/zhicli/git/clouddriver/src/file/python/get-put-file.py g /home/zhicli/git/clouddriver/src/file/python/xmlfile clouddriver"); 
	if(ret == -1) 
		perror("python script error"); 
	//system("/home/zhicli/git/clouddriver/src/file/python/operate-xml.py delete /ttt 1 /home/zhicli/git/clouddriver/src/file/python/xmlfile /home/zhicli/git/clouddriver/src/file/cache"); 
	//system("/home/zhicli/git/clouddriver/src/file/python/xml-to-dir.py /home/zhicli/git/clouddriver/src/file/python/xmlfile /home/zhicli/git/clouddriver/src/file/cache"); 
	//system("/home/zhicli/git/clouddriver/src/file/python/sync.py /home/zhicli/git/clouddriver/src/file/changelist /home/zhicli/git/clouddriver/src/file/cache clouddriver"); 
	//system("/home/zhicli/git/clouddriver/src/file/python/get-put-file.py p /home/zhicli/git/clouddriver/src/file/python/xmlfile clouddriver"); 

    return 0;
}
