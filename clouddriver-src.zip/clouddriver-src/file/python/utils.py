import os
import re
from xml.dom import Node

# The key pairs are from /doc/aws-access-keys/credentials.cvs
# FIXME: it should be encrypted for safty. 
aws_access_key = 'AKIAILNOHJQ2EPDQA5RA'
aws_secret_key = '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'

# get fuse path from fullpath by removing cachedir from fullpath
# e.g:
# fullpath: /mnt/clouddrive/dir/test, cachedir: /mnt/clouddrive
# return: /dir/test
def getFusePath(fullpath, cachedir, logfile):
    fullpathlist = re.split('\/', fullpath)
    cachedirlist = re.split('\/', cachedir)
    for i in range(len(cachedirlist)):
        if fullpathlist[i] != cachedirlist[i]:
            logfile.write("cachedir doesn't match prefix of fullpath")
            return -1
    fusepath = '/'.join(fullpathlist[len(cachedirlist):])
    fusepath = '/' + fusepath
    return fusepath
    
# get the key for a path
# path is absolute, starting from root, replace each 
# '/' in the path with '#', excluding the starting '/'
# e.g: 
# /mnt/clouddrive-metadata/xmlfile => mnt#clouddrive-metadata#xmlfile
#
# if cachedir is specified, then remove cachedir from fullpath to get
# FUSE path. 
# e.g:
# /mnt/clouddrive/dir/test => /dir/test => dir#test
#
def getKeyFromPath(path, cachedir, logfile):
    if cachedir != 0:
    # remove cachedir prefix from path
        path = getFusePath(path, cachedir, logfile)
        if path == -1:
            logfile.write("getfusepath() failed: prefix does not match")
            return -1
    pathcomponents = re.split('\/', path)
    key = "#".join(pathcomponents[1:len(pathcomponents)])
    return key

# get the path from a key
# e.g:
# mnt#clouddrive#test => /mnt/clouddrive/test
#
def getPathFromKey(key):
    keycomponents = re.split('#', key)
    path = '/'.join(keycomponents)
    # add the starting '/'
    path = '/' + path
    return path

# collect metadata for a file
#
def collectMetadata(fullpath, elem, f):
    stat = os.stat(fullpath)
    # ID of device containing file
    elem.setAttribute('dev', unicode(stat.st_dev))
    # inode number
    elem.setAttribute('ino', unicode(stat.st_ino))
    # file mode for protection
    elem.setAttribute('mode', unicode(stat.st_mode))
    # number of hard links
    elem.setAttribute('nlink', unicode(stat.st_nlink))
    # user ID of owner
    elem.setAttribute('uid', unicode(stat.st_uid))
    # group ID of owner
    elem.setAttribute('gid', unicode(stat.st_gid))
    # device ID (if special file)
    elem.setAttribute('rdev', unicode(stat.st_rdev))
    # total size, in bytes
    elem.setAttribute('size', unicode(stat.st_size))
    # block size for file system IO
    elem.setAttribute('blksize', unicode(stat.st_blksize))
    # number of 512B blocks allocated
    elem.setAttribute('blocks', unicode(stat.st_blocks))
    # last access time
    elem.setAttribute('atime', unicode(stat.st_atime))
    # last modification time
    elem.setAttribute('mtime', unicode(stat.st_mtime))
    # last status change time
    elem.setAttribute('ctime', unicode(stat.st_ctime))
    
    # file name, in relevant path
    elem.setAttribute('name', f)

# Given a path, extract the next dir from it. Also return the left path
# e.g: for a path such as ./dir2/test2, return (., and dir2/test2) on first
# call and return (dir2, test2) on the second call
#     
def extractNextDirFromPath(path):
    pathcomponents = re.split('\/', path)
    if len(pathcomponents) == 1:
        return (path, 0)
    else:
        leftpath = '/'.join(pathcomponents[1:len(pathcomponents)])
        return (pathcomponents[0], leftpath)

# find the right subnode in an XML node for continuing the search
# TODO: 1. need verification (large scale) 2. better func doc
def findSubnode(node, leftpath, mode, logfile):
    #print "leftpath: " + leftpath
    (nextdir, leftpath) = extractNextDirFromPath(leftpath)
    for childnode in node.childNodes:
        if childnode.nodeType == Node.ELEMENT_NODE:
            name = childnode.getAttribute('name')
            if name == nextdir:
                # find the right next node
                if leftpath != 0 and childnode.tagName == 'Dir':
                    # continue search
                    return findsubnode(childnode, leftpath, mode)
                elif leftpath != 0 and childnode.tagName == 'File':
                    # find a file!
                    logfile.write("find a file, not dir for " + name)
                    return -1
                else:
                    # we find the right file, need to check type
                    if (childnode.tagName == 'File' and int(mode) != 0) or \
                       (childnode.tagName == 'Dir' and int(mode) == 0):
                            return childnode
                    else:
                        # type mismatch
                        logfile.write("type mismatch for " + name)
                        return -1
            else:
                continue
        else:
            continue
    return -1

# get the dir node for the longest matching prefix
# path and existingpath are relative to rootdir. path denotes the path we want
# to check and existingpath denotes the path of dirs which already exist
#
# e.g:
#    Given a path for newfile as ./dir2/dir3/dir4/newfile and assume dirs 
#    starting from dir3 are newly created. This function should return a node 
#    for dir2. We will repeatedly create nodes for dir3, dir4 and newfile with
#    another function called createNode(). 
#
#    TODO: 1. format func name; 2. better func doc; 
# 
def getLongestMatchingDirNode(node, path, existingpath, logfile):
    (nextdir, leftpath) = extractNextDirFromPath(path)
    for childnode in node.childNodes:
        if childnode.nodeType == Node.ELEMENT_NODE:
            name = childnode.getAttribute('name')
            if name == nextdir:
                # find the right next node
                if leftpath != 0 and childnode.tagName == 'Dir':
                    # continue search
                    if existingpath == 0:
                        existingpath = nextdir
                    else:
                        existingpath += '/' + nextdir
                    (node, path, existingpath) = getLongestMatchingDirNode(childnode, 
                             leftpath, existingpath, logfile)
                elif leftpath != 0 and childnode.tagName == 'File':
                    # find a file!
                    logfile.write("find a file, not dir for " + name)
                    return -1
                else:
                    # leftpath == 0
                    logfile.write("not suppose to find a file/dir")
                    return -1
                break;
        else:# childnode is not an element
            continue
    # return the longest matching parent dir and left path
    return (node, path, existingpath)

# create nodes for components in path in the dir, represented by parentnode
# prefixpath/leftpath == fullpath
def createNode(doc, parentnode, leftpath, prefixpath, mode):
    #print 'prefix: ' + prefixpath + ",leftpath: " + leftpath
    (nextdir, leftpath) = extractNextDirFromPath(leftpath)
    if leftpath == 0:
        # create a file node
        if mode == 0:
            node = doc.createElement('Dir')
        else:
            node = doc.createElement('File')
        # call collectMetadata() to get attributes for this node
        fullpath = prefixpath + '/' + nextdir
        collectMetadata(fullpath, node, nextdir)
        parentnode.appendChild(node)
    else:
        # create this dir
        node = doc.createElement('Dir')
        fullpath = prefixpath + '/' + nextdir
        collectMetadata(fullpath, node, nextdir)
        parentnode.appendChild(node)
        createNode(doc, node, leftpath, prefixpath+'/' + nextdir, mode)

# call doc.toprettyXML() and remove empty lines
def getprettyXML(doc):
    prettyXML = doc.toprettyxml(" ", "\n", "UTF-8")
    # remove empty lines 
    newprettyXML = ''
    for line in prettyXML.split('\n'):
        if line.strip():
           newprettyXML += line + '\n'
    return newprettyXML
