#!/usr/bin/env python
#
# Given a file containing a list of changed files, this script will create 
# a tarball for each file and store the tarball into S3. Compression and 
# encryption is applied to the tarball before transferring by default. 
#
# Each record in the changelist file is full path in the cache dir, 
# not relative to the mount point. So, we need the cache dir as input
# to get fuse path.
#
# FIXME: sync.py should be smart enough to process the changelist. 
#

from boto.s3.connection import S3Connection
from boto.s3.key import Key

import sys
from optparse import OptionParser
import os
import re
import utils

# We defined these two keys in the utils module
aws_access_key = utils.aws_access_key
aws_secret_key = utils.aws_secret_key

logfile = sys.argv[0] + '.log'
try:
    # open log file in append mode
    logf = open(logfile, 'a')
except IOError:
    print "failed to open log file\nExit"
    exit(1)

# TODO: think in the overall system view, the backend may need to
# take care of separate files, not just the changelist
usagestr = \
  "Usage: ./sync.py changedlistPath cachedir bucketname\n"

def usage():
    logf.write(usagestr)
    logf.close()
    sys.exit(1)

if len(sys.argv) != 4:
    usage()

changelist = sys.argv[1]
inputfile = changelist + '_dedup'
cachedir = sys.argv[2]
bucketname = sys.argv[3]
user = "Michael"
tmp = "/tmp/"

# dedup changelist
ret = os.system("sort " + changelist + " | uniq > " + inputfile)
if ret == -1:
    logf.write("ERROR in sort changelist\n")
    logf.close()
    exit(ret)

# For each changed file, create a tarball, compress and then encrypt the 
# tarball.
try:
    f = open(inputfile, 'r')
except IOError:
    logf.write("failed to open changelist file for reading\n")
    logf.close()
    exit(1)

for file in f:
    file = file.rstrip()
    logf.write("sync file: " + file + " starts\n")
    # construct the name of the tarball from the path. 
    segment = utils.getKeyFromPath(file, cachedir, logf)
    if segment == -1:
        logf.write("getKeyFromPath() failed\n")
        logf.close()
        exit(1)
    logf.write("step --> got the key: " + segment + "\n"); 

    # First verify the existance 
    if(os.path.exists(file) is False):
        s = file + " does not exist in cache\n"
        logf.write(s)
        logf.close()
        exit(1)

    # step1: create an tarball with compression and encryption
    # 1.a create the tarball
    logf.write("step --> tar -cf " + file + "\n"); 
    ret = os.system("tar" + " -cf " + tmp + segment + ".tar " + file)
    if ret == -1:
        logf.write("failed to create tarball for " + file + "\n")
        f.close()
        logf.close()
        exit(ret)

    # 1.b compress the tarball
    logf.write("step --> gzip -c " + file + "\n"); 
    ret = os.system("gzip -c " + tmp + segment + ".tar > " \
            + tmp + segment + ".tar.gz")
    if ret == -1:
        logf.write("failed to compress tarball for " + file + "\n")
        os.system("rm " + tmp + segment + ".tar")
        f.close()
        logf.close()
        exit(ret)
         
    # 1.c encrypt the tarball
    # before perform the following command, please do gpg --gen-key and
    # create key pairs for Michael/Xing
#    ret = os.system("gpg -e -r " + user + " " + segment + ".tar.gz")
#    if ret == -1:
#        logf.write("failed to encrypt tarball for " + file + "\n")
#        os.system("rm " + segment + ".tar")
#        os.system("rm " + segment + ".tar.gz")
#        f.close()
#        logf.close()
#        exit(ret)

    # step2: store the tarball at S3
    conn = S3Connection(aws_access_key, aws_secret_key)
    # get the specified bucket object
    logf.write("step --> conn.get_bucket()\n"); 
    bucket = conn.get_bucket(bucketname)
    # create a key with the key name to be segment and the key value to be the 
    # tarball
    logf.write("step --> Key()\n"); 
    k = Key(bucket)
    k.key = segment
#    f2 = open(segment + ".tar.gz.gpg", 'r')
    try:
        f2 = open(tmp + segment + ".tar.gz", 'r')
    except IOError:
        logf.write("ERROR to open " + tmp + segment + ".tar.gz\n"); 
        logf.close()
        exit(1)

    # Overwrite if the key already exists 
    try:
        logf.write("step --> k.set_contents_from_string() " + file + "\n"); 
        k.set_contents_from_string(f2.read())
    except boto.exception.S3ResponseError:
        # For the moment, if the key doesn't exist, we create an empty file. 
        logf.write("ERROR PUT " + file + " to S3\n")
        f2.close()
        logf.close()
        exit(1)
    f2.close()
    logf.write("sync file: " + file + " finished!\n")

    # remove temporary files
    os.system("rm " + tmp + segment + ".tar")
    os.system("rm " + tmp + segment + ".tar.gz")
#    os.system("rm " + segment + ".tar.gz.gpg")
f.close()
logf.close()

#verify = k.get_contents_as_string()
#print "verify: " + verify
