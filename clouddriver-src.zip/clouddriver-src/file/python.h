/* 
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#ifndef _PYTHON_H_
#define _PYTHON_H_
#include <stdio.h>

#include "clouddriver.h"
#include "log.h"

extern int operate_xml(const char * fusePath, mode_t mode, unsigned int opr); 
extern int xml_to_dir(); 

#endif
