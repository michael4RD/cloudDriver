/* 
 * Copyright (c) 2012 Zhichao Li, Xing Lin
 * Copyright (c) 2012 Stony Brook University, University of Utah
 *  
 *  Synchronization between FUSE cache and AWS. 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#include "sync.h"

/* sync single file with @path with operation @opr */
int sync_file(const char * fullPath, unsigned int opr) {
	int ret = 0; 
	char s[CMD_LEN]; 
	char c; 

    switch(opr) {
        case GET: 
            c = 'g'; 
            break; 
        case PUT: 
            c = 'p'; 
            break; 
        case DEL: 
            c = 'd'; 
            break; 
        default: 
		    log_msg("ERROR: sync_file() wrong operation opr %u\n", opr); 
            break; 
    }

#ifdef PYTHON_FINISHED
	sprintf(s, "%s %c %s %s %s", getputfilePath.c_str(), 
		   	c, fullPath, bucketName.c_str(), clouddriver_data->rootdir); 
	log_msg("sync_file(\'%c\') starts with system(\"%s\")\n", c, s); 
	ret = system(s); 
	if (ret == -1) 
		ret = clouddriver_error("sync_file() calling python/get-put-file.py"); 
#endif

	return ret; 
}

/* sync all files/dirs under @rootdir */
int sync_all(const char * rootdir) {
	int ret = 0; 
	char s[CMD_LEN]; 

#ifdef PYTHON_FINISHED
	sprintf(s, "%s %s %s %s", syncfilePath.c_str(), changelistPath.c_str(), 
			clouddriver_data->rootdir, bucketName.c_str()); 
	log_msg("sync_all() starts with system(\"%s\")\n", s); 
	ret = system(s); 
	if (ret == -1) 
 		ret = clouddriver_error("sync_all() calling python/sync.py"); 
#endif

	return ret; 
}

int sync_xml(unsigned int opr) {
	int ret = 0; 
	char s[CMD_LEN]; 
    /* Only get and put operations for XML file */
	char c = (opr==GET)?'g':'p'; 

#ifdef PYTHON_FINISHED
	sprintf(s, "%s %c %s %s", getputfilePath.c_str(), c, xmlPath.c_str(), 
			bucketName.c_str()); 
	log_msg("sync_xml(\'%c\') starts with system(\"%s\")\n", c, s); 
	ret = system(s); 
	if (ret == -1) 
		ret = clouddriver_error("sync_file() calling python/get-put-file.py"); 
#endif

	return ret; 
}
